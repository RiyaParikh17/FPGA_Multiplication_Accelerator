`timescale 1ns / 1ps

module mux_y (

    input  wire [31:0] alu_result,
    input  wire [31:0] memory_data,
    input  wire [31:0] pc_plus_4,

    // Writeback selection
    // 00 = ALU result
    // 01 = Memory data
    // 10 = PC + 4
    input  wire [1:0]  wb_sel,

    output wire [31:0] writeback_data
);

    assign writeback_data =
        (wb_sel == 2'b00) ? alu_result   :
        (wb_sel == 2'b01) ? memory_data  :
        (wb_sel == 2'b10) ? pc_plus_4    :
                            32'b0;

endmodule