module register_file (
    input              clk,
    input              we,
    input      [4:0]   rs1,
    input      [4:0]   rs2,
    input      [4:0]   rd,
    input      [31:0]  wd,

    output     [31:0]  rd1,
    output     [31:0]  rd2,

    // All 32 registers
    output     [1023:0] registers_out
);

    // 32 Registers, each 32 bits
    reg [31:0] registers [0:31];

    integer i;

    // Initialize registers to zero
    initial begin
        for (i = 0; i < 32; i = i + 1)
            registers[i] = 32'b0;
    end

    // Write Operation
    always @(posedge clk) begin
        if (we && (rd != 5'd0))
            registers[rd] <= wd;
    end

    // Read Operation
    assign rd1 = (rs1 == 5'd0) ? 32'b0 : registers[rs1];
    assign rd2 = (rs2 == 5'd0) ? 32'b0 : registers[rs2];

    // Combine all 32 registers into one 1024-bit output
    genvar j;

    generate
        for (j = 0; j < 32; j = j + 1) begin
            assign registers_out[j*32 +: 32] = registers[j];
        end
    endgenerate

endmodule