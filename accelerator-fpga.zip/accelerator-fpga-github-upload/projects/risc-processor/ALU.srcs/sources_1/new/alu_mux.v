`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 13.08.2026 23:06:31
// Design Name: 
// Module Name: alu_mux
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module alu_mux (
    input  wire [31:0] rs2_data,
    input  wire [31:0] immediate,
    input  wire        alu_src,
    output wire [31:0] alu_b
);

assign alu_b = alu_src ? immediate : rs2_data;

endmodule
