`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 11.08.2026 15:27:30
// Design Name: 
// Module Name: immediate_generator
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


`timescale 1ns / 1ps

module immediate_generator (
    input  [31:0] instruction,
    input  [2:0]  imm_sel,
    output reg [31:0] immediate
);

    // Immediate format selection
    localparam IMM_R = 3'b000;
    localparam IMM_I = 3'b001;
    localparam IMM_S = 3'b010;
    localparam IMM_B = 3'b011;
    localparam IMM_U = 3'b100;
    localparam IMM_J = 3'b101;

    always @(*) begin

        case (imm_sel)

            // R type
            // No immediate
            IMM_R:
                immediate = 32'b0;

            // I type
            // imm[11:0] = instruction[31:20]
            IMM_I:
                immediate = {{20{instruction[31]}},
                             instruction[31:20]};

            // S type
            // imm[11:5] = instruction[31:25]
            // imm[4:0]  = instruction[11:7]
            IMM_S:
                immediate = {{20{instruction[31]}},
                             instruction[31:25],
                             instruction[11:7]};

            // B type
            // imm[12]   = instruction[31]
            // imm[11]   = instruction[7]
            // imm[10:5] = instruction[30:25]
            // imm[4:1]  = instruction[11:8]
            // imm[0]    = 0
            IMM_B:
                immediate = {{19{instruction[31]}},
                             instruction[31],
                             instruction[7],
                             instruction[30:25],
                             instruction[11:8],
                             1'b0};

            // U type
            // imm[31:12] = instruction[31:12]
            // imm[11:0]  = 0
            IMM_U:
                immediate = {instruction[31:12],
                             12'b0};

            // J type
            // imm[20]    = instruction[31]
            // imm[19:12] = instruction[19:12]
            // imm[11]    = instruction[20]
            // imm[10:1]  = instruction[30:21]
            // imm[0]     = 0
            IMM_J:
                immediate = {{11{instruction[31]}},
                             instruction[31],
                             instruction[19:12],
                             instruction[20],
                             instruction[30:21],
                             1'b0};

            // Invalid selection
            default:
                immediate = 32'b0;

        endcase

    end

endmodule
