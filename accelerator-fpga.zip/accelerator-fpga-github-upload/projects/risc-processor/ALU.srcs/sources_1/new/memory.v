`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 15.08.2026 15:43:01
// Design Name: 
// Module Name: memory
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module memory #(
    parameter DATA_WIDTH = 32,
    parameter ADDR_WIDTH = 10
)(
    input  wire                     clk,
    input  wire                     mem_read,
    input  wire                     mem_write,

    input  wire [ADDR_WIDTH-1:0]    address,
    input  wire [DATA_WIDTH-1:0]    write_data,

    output reg  [DATA_WIDTH-1:0]    read_data,

    // Debug output: entire memory contents
    output wire [(DATA_WIDTH*(1<<ADDR_WIDTH))-1:0] debug_memory
);

    // Memory array
    reg [DATA_WIDTH-1:0] mem [0:(1<<ADDR_WIDTH)-1];

    // Memory operations
    always @(posedge clk) begin

        // Store Word
        if (mem_write) begin
            mem[address] <= write_data;
        end

        // Load Word
        if (mem_read) begin
            read_data <= mem[address];
        end

    end

    // Flatten entire memory into one debug bus
    genvar i;

    generate
        for (i = 0; i < (1<<ADDR_WIDTH); i = i + 1) begin : DEBUG_MEMORY
            assign debug_memory[
                (i*DATA_WIDTH) +: DATA_WIDTH
            ] = mem[i];
        end
    endgenerate

endmodule
