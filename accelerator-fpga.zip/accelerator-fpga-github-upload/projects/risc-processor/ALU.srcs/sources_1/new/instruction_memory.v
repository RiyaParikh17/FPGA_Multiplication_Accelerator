`timescale 1ns / 1ps

module instruction_memory #(
    parameter DATA_WIDTH = 32,
    parameter ADDR_WIDTH = 10
)(
    input  wire                     clk,
    input  wire [31:0]              pc,

    output reg  [DATA_WIDTH-1:0]    instruction,

    // Debug output for simulation
    output wire [(DATA_WIDTH*(1<<ADDR_WIDTH))-1:0] debug_memory
);

    // =========================================================
    // Instruction Memory
    //
    // 1024 locations × 32 bits = 4 KB
    // =========================================================

    reg [DATA_WIDTH-1:0] mem [0:(1<<ADDR_WIDTH)-1];


    // =========================================================
    // Program initialization
    // =========================================================

    integer i;

    initial begin

        // -----------------------------------------------------
        // JALR TEST PROGRAM
        // -----------------------------------------------------

        // PC = 0
        // ADDI x1, x0, 20
        //
        // x1 = 20
        mem[0] = 32'h01400093;


        // PC = 4
        // JALR x5, 8(x1)
        //
        // Target:
        //
        // x1 + 8
        // 20 + 8 = 28
        //
        // Link:
        //
        // x5 = PC + 4
        //    = 4 + 4
        //    = 8
        //
        // Therefore execution jumps to mem[7].
        mem[1] = 32'h008082E7;


        // PC = 8
        // ADDI x2, x0, 99
        //
        // SHOULD BE SKIPPED
        mem[2] = 32'h06300113;


        // PC = 12
        // ADDI x2, x0, 88
        //
        // SHOULD BE SKIPPED
        mem[3] = 32'h05800113;


        // PC = 16
        // ADDI x2, x0, 77
        //
        // SHOULD BE SKIPPED
        mem[4] = 32'h04D00113;


        // PC = 20
        // ADDI x2, x0, 66
        //
        // SHOULD BE SKIPPED
        mem[5] = 32'h04200113;


        // PC = 24
        // ADDI x2, x0, 55
        //
        // SHOULD BE SKIPPED
        mem[6] = 32'h03700113;


        // PC = 28
        // ADDI x3, x0, 30
        //
        // JALR TARGET
        //
        // THIS INSTRUCTION SHOULD EXECUTE
        mem[7] = 32'h01E00193;


        // -----------------------------------------------------
        // Rest of memory initialized to NOP
        // -----------------------------------------------------

        for (i = 8; i < (1<<ADDR_WIDTH); i = i + 1)
            mem[i] = 32'h00000013;

    end


    // =========================================================
    // Instruction Fetch
    //
    // PC is a byte address.
    //
    // PC[ADDR_WIDTH+1:2] selects the 32-bit instruction word.
    // =========================================================

    always @(posedge clk) begin

        instruction <= mem[pc[ADDR_WIDTH+1:2]];

    end


    // =========================================================
    // Debug output
    // =========================================================

    genvar j;

    generate

        for (j = 0; j < (1<<ADDR_WIDTH); j = j + 1) begin : DEBUG_MEMORY

            assign debug_memory[
                (j*DATA_WIDTH) +: DATA_WIDTH
            ] = mem[j];

        end

    endgenerate

endmodule