`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 11.08.2026 15:54:08
// Design Name: 
// Module Name: instruction_decoder
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////




module instruction_decoder (

    input  [31:0] instruction,

    // Register addresses
    output [4:0] rs1,
    output [4:0] rs2,
    output [4:0] rd,

    // Instruction information
    output [6:0] opcode,
    output reg   alu_src,
    output reg [3:0] alu_op,
    output reg [2:0] instruction_format,
    output reg [2:0] branch_type,

    // Branch and jump identification
    output reg jump,
    output reg jalr,
    output reg [2:0] execution_type
);


    // ============================================================
    // RISC V OPCODES
    // ============================================================

    parameter OPCODE_R      = 7'b0110011;  // R type ALU
    parameter OPCODE_I      = 7'b0010011;  // I type ALU
    parameter OPCODE_LOAD   = 7'b0000011;  // LW
    parameter OPCODE_STORE  = 7'b0100011;  // SW
    parameter OPCODE_BRANCH = 7'b1100011;  // Branch
    parameter OPCODE_JAL    = 7'b1101111;  // JAL
    parameter OPCODE_JALR   = 7'b1100111;


    // ============================================================
    // RISC V INSTRUCTION FORMATS
    // ============================================================

    parameter FORMAT_R = 3'b000;
    parameter FORMAT_I = 3'b001;
    parameter FORMAT_S = 3'b010;
    parameter FORMAT_B = 3'b011;
    parameter FORMAT_U = 3'b100;
    parameter FORMAT_J = 3'b101;


    // ============================================================
    // ALU OPERATIONS
    // Must match ALU module
    // ============================================================

    parameter ALU_ADD  = 4'b0000;
    parameter ALU_SUB  = 4'b0001;
    parameter ALU_AND  = 4'b0010;
    parameter ALU_OR   = 4'b0011;
    parameter ALU_XOR  = 4'b0100;
    parameter ALU_SLL  = 4'b0101;
    parameter ALU_SRL  = 4'b0110;
    parameter ALU_SRA  = 4'b0111;
    parameter ALU_SLT  = 4'b1000;
    parameter ALU_SLTU = 4'b1001;
    
    // ============================================================
    // BRANCH TYPE
    // ============================================================

    parameter BR_BEQ  = 3'b000;
    parameter BR_BNE  = 3'b001;
    parameter BR_BLT  = 3'b010;
    parameter BR_BGE  = 3'b011;
    parameter BR_BLTU = 3'b100;
    parameter BR_BGEU = 3'b101;
    parameter BR_NONE = 3'b111;   

    // ============================================================
    // FSM Control instruction types
    // ============================================================
    
    parameter EXEC_ALU           = 3'b000;
    parameter EXEC_LOAD          = 3'b001;
    parameter EXEC_STORE         = 3'b010;
    parameter EXEC_CONTROL_FLOW  = 3'b011;
    parameter EXEC_JUMP          = 3'b100;

    // ============================================================
    // INSTRUCTION FIELDS
    // ============================================================

    wire [2:0] funct3;
    wire       funct7;

    assign opcode = instruction[6:0];
    assign funct3 = instruction[14:12];
    assign funct7 = instruction[30];


    // ============================================================
    // REGISTER ADDRESSES
    // ============================================================

    assign rs1 = instruction[19:15];
    assign rs2 = instruction[24:20];
    assign rd  = instruction[11:7];


    // ============================================================
    // INSTRUCTION DECODER
    // ============================================================

    always @(*) begin

    // ============================================================
    // DEFAULT VALUES
    // ============================================================

    alu_src            = 1'b0;
    alu_op             = ALU_ADD;
    instruction_format = FORMAT_R;

    execution_type     = EXEC_ALU;

    branch_type        = BR_NONE;
    jump               = 1'b0;
    jalr               = 1'b0;


    // ============================================================
    // OPCODE DECODE
    // ============================================================

    case (opcode)


        // ========================================================
        // R TYPE ALU
        //
        // ADD
        // SUB
        // AND
        // OR
        // XOR
        // SLL
        // SRL
        // SRA
        // SLT
        // SLTU
        // ========================================================

        OPCODE_R: begin

            alu_src            = 1'b0;
            execution_type     = EXEC_ALU;
            instruction_format = FORMAT_R;

            case (funct3)

                // ADD / SUB
                3'b000: begin

                    if (funct7 == 1'b0)
                        alu_op = ALU_ADD;
                    else
                        alu_op = ALU_SUB;

                end


                // SLL
                3'b001:
                    alu_op = ALU_SLL;


                // SLT
                3'b010:
                    alu_op = ALU_SLT;


                // SLTU
                3'b011:
                    alu_op = ALU_SLTU;


                // XOR
                3'b100:
                    alu_op = ALU_XOR;


                // SRL / SRA
                3'b101: begin

                    if (funct7 == 1'b0)
                        alu_op = ALU_SRL;
                    else
                        alu_op = ALU_SRA;

                end


                // OR
                3'b110:
                    alu_op = ALU_OR;


                // AND
                3'b111:
                    alu_op = ALU_AND;


                default:
                    alu_op = ALU_ADD;

            endcase

        end


        // ========================================================
        // I TYPE ALU
        //
        // ADDI
        // SLTI
        // SLTIU
        // XORI
        // ORI
        // ANDI
        // SLLI
        // SRLI
        // SRAI
        // ========================================================

        OPCODE_I: begin

            alu_src            = 1'b1;
            execution_type     = EXEC_ALU;
            instruction_format = FORMAT_I;

            case (funct3)

                // ADDI
                3'b000:
                    alu_op = ALU_ADD;


                // SLLI
                3'b001:
                    alu_op = ALU_SLL;


                // SLTI
                3'b010:
                    alu_op = ALU_SLT;


                // SLTIU
                3'b011:
                    alu_op = ALU_SLTU;


                // XORI
                3'b100:
                    alu_op = ALU_XOR;


                // SRLI / SRAI
                3'b101: begin

                    if (funct7 == 1'b0)
                        alu_op = ALU_SRL;
                    else
                        alu_op = ALU_SRA;

                end


                // ORI
                3'b110:
                    alu_op = ALU_OR;


                // ANDI
                3'b111:
                    alu_op = ALU_AND;


                default:
                    alu_op = ALU_ADD;

            endcase

        end


        // ========================================================
        // LOAD
        //
        // LW
        // ========================================================

        OPCODE_LOAD: begin

            // Address = rs1 + immediate

            alu_src            = 1'b1;
            alu_op             = ALU_ADD;
            execution_type     = EXEC_LOAD;
            instruction_format = FORMAT_I;

        end


        // ========================================================
        // STORE
        //
        // SW
        // ========================================================

        OPCODE_STORE: begin

            // Address = rs1 + immediate

            alu_src            = 1'b1;
            alu_op             = ALU_ADD;
            execution_type     = EXEC_STORE;
            instruction_format = FORMAT_S;

        end


        // ========================================================
        // CONDITIONAL CONTROL FLOW
        //
        // BEQ
        // BNE
        // BLT
        // BGE
        // BLTU
        // BGEU
        // ========================================================

        OPCODE_BRANCH: begin

            alu_src            = 1'b0;
            execution_type     = EXEC_CONTROL_FLOW;
            instruction_format = FORMAT_B;


            case (funct3)

                // ------------------------------------------------
                // BEQ
                // ------------------------------------------------

                3'b000: begin

                    alu_op      = ALU_SUB;
                    branch_type = BR_BEQ;

                end


                // ------------------------------------------------
                // BNE
                // ------------------------------------------------

                3'b001: begin

                    alu_op      = ALU_SUB;
                    branch_type = BR_BNE;

                end


                // ------------------------------------------------
                // BLT
                // ------------------------------------------------

                3'b100: begin

                    alu_op      = ALU_SLT;
                    branch_type = BR_BLT;

                end


                // ------------------------------------------------
                // BGE
                // ------------------------------------------------

                3'b101: begin

                    alu_op      = ALU_SLT;
                    branch_type = BR_BGE;

                end


                // ------------------------------------------------
                // BLTU
                // ------------------------------------------------

                3'b110: begin

                    alu_op      = ALU_SLTU;
                    branch_type = BR_BLTU;

                end


                // ------------------------------------------------
                // BGEU
                // ------------------------------------------------

                3'b111: begin

                    alu_op      = ALU_SLTU;
                    branch_type = BR_BGEU;

                end


                // ------------------------------------------------
                // Invalid branch
                // ------------------------------------------------

                default: begin

                    alu_op      = ALU_ADD;
                    branch_type = BR_NONE;

                end

            endcase

        end


        // ========================================================
        // JAL
        // ========================================================

        OPCODE_JAL: begin

            // ----------------------------------------------------
            // JAL changes PC
            //
            // PC       = PC + jump_offset
            // rd       = PC + 4
            //
            // The writeback source PC + 4 is selected later by
            // the FSM using EXEC_JUMP.
            // ----------------------------------------------------

            alu_src            = 1'b0;
            alu_op             = ALU_ADD;

            execution_type     = EXEC_JUMP;
            instruction_format = FORMAT_J;

            jump               = 1'b1;

        end
        
        // ========================================================
        // JALR
        // ========================================================

        OPCODE_JALR: begin

        // ----------------------------------------------------
        // JALR target:
        //
        // target = rs1 + immediate
        //
        // ALU calculates rs1 + I-type immediate.
        //
        // rd = PC + 4
        // ----------------------------------------------------

        alu_src            = 1'b1;
        alu_op             = ALU_ADD;

        execution_type     = EXEC_JUMP;
        instruction_format = FORMAT_I;

        jalr               = 1'b1;

        end


        // ========================================================
        // UNSUPPORTED INSTRUCTION
        // ========================================================

        default: begin

            alu_src            = 1'b0;
            alu_op             = ALU_ADD;

            execution_type     = EXEC_ALU;
            instruction_format = FORMAT_R;

            branch_type        = BR_NONE;
            jump               = 1'b0;

        end

    endcase

end
endmodule