`timescale 1ns / 1ps

module controller_fsm (

    input  wire       clk,
    input  wire       reset,

    // From instruction decoder
    input  wire [2:0] execution_type,

    // Control signals
    output reg        mem_read,
    output reg        mem_write,

    // Writeback control
    output reg [1:0]  wb_sel,
    output reg        reg_write,

    // PC control
    output reg        pc_update,

    // Current FSM state
    output reg [2:0]  state

);


    // ============================================================
    // EXECUTION TYPES
    // Must match instruction_decoder
    // ============================================================

    parameter EXEC_ALU           = 3'b000;
    parameter EXEC_LOAD          = 3'b001;
    parameter EXEC_STORE         = 3'b010;
    parameter EXEC_CONTROL_FLOW  = 3'b011;
    parameter EXEC_JUMP          = 3'b100;


    // ============================================================
    // WRITEBACK SELECT
    //
    // 00 = ALU result
    // 01 = Memory data
    // 10 = PC + 4
    // ============================================================

    parameter WB_ALU  = 2'b00;
    parameter WB_MEM  = 2'b01;
    parameter WB_PC4  = 2'b10;


    // ============================================================
    // FSM STATES
    // ============================================================

    parameter STATE_EXECUTE   = 3'b000;
    parameter STATE_MEM_READ  = 3'b001;
    parameter STATE_MEM_WRITE = 3'b010;
    parameter STATE_WRITEBACK = 3'b011;
    parameter STATE_DONE      = 3'b100;


    reg [2:0] next_state;


    // ============================================================
    // STATE REGISTER
    //
    // reset is ACTIVE LOW
    //
    // reset = 0 → EXECUTE
    // reset = 1 → normal operation
    // ============================================================

    always @(posedge clk or negedge reset) begin

        if (!reset)
            state <= STATE_EXECUTE;

        else
            state <= next_state;

    end


    // ============================================================
    // NEXT STATE LOGIC
    // ============================================================

    always @(*) begin

        // Default
        next_state = state;

        case (state)


            // ====================================================
            // EXECUTE
            // ====================================================

            STATE_EXECUTE: begin

                case (execution_type)

                    // --------------------------------------------
                    // ALU instruction
                    // --------------------------------------------

                    EXEC_ALU: begin

                        next_state = STATE_WRITEBACK;

                    end


                    // --------------------------------------------
                    // LOAD instruction
                    // --------------------------------------------

                    EXEC_LOAD: begin

                        next_state = STATE_MEM_READ;

                    end


                    // --------------------------------------------
                    // STORE instruction
                    // --------------------------------------------

                    EXEC_STORE: begin

                        next_state = STATE_MEM_WRITE;

                    end


                    // --------------------------------------------
                    // Conditional control flow
                    //
                    // BEQ
                    // BNE
                    // BLT
                    // BGE
                    // BLTU
                    // BGEU
                    //
                    // No register writeback
                    // --------------------------------------------

                    EXEC_CONTROL_FLOW: begin

                        next_state = STATE_DONE;

                    end


                    // --------------------------------------------
                    // Unconditional jump
                    //
                    // JAL
                    //
                    // Writes PC + 4 to rd
                    // --------------------------------------------

                    EXEC_JUMP: begin

                        next_state = STATE_WRITEBACK;

                    end


                    // --------------------------------------------
                    // Invalid execution type
                    // --------------------------------------------

                    default: begin

                        next_state = STATE_DONE;

                    end

                endcase

            end


            // ====================================================
            // MEMORY READ
            // ====================================================

            STATE_MEM_READ: begin

                next_state = STATE_WRITEBACK;

            end


            // ====================================================
            // MEMORY WRITE
            // ====================================================

            STATE_MEM_WRITE: begin

                next_state = STATE_DONE;

            end


            // ====================================================
            // WRITEBACK
            // ====================================================

            STATE_WRITEBACK: begin

                next_state = STATE_DONE;

            end


            // ====================================================
            // DONE
            // ====================================================

            STATE_DONE: begin

                next_state = STATE_EXECUTE;

            end


            // ====================================================
            // DEFAULT
            // ====================================================

            default: begin

                next_state = STATE_EXECUTE;

            end

        endcase

    end


    // ============================================================
    // CONTROL SIGNAL GENERATION
    // ============================================================

    always @(*) begin

        // --------------------------------------------------------
        // DEFAULT VALUES
        // --------------------------------------------------------

        mem_read  = 1'b0;
        mem_write = 1'b0;

        wb_sel    = WB_ALU;
        reg_write = 1'b0;

        pc_update = 1'b0;


        // --------------------------------------------------------
        // PC UPDATE
        //
        // PC updates when the current instruction completes.
        //
        // This includes:
        //
        // ALU
        // LOAD
        // STORE
        // CONTROL FLOW
        // JUMP
        // --------------------------------------------------------

        if ((state != STATE_DONE) &&
            (next_state == STATE_DONE)) begin

            pc_update = 1'b1;

        end


        // --------------------------------------------------------
        // STATE DEPENDENT CONTROL
        // --------------------------------------------------------

        case (state)


            // ====================================================
            // EXECUTE
            // ====================================================

            STATE_EXECUTE: begin

                mem_read  = 1'b0;
                mem_write = 1'b0;

                reg_write = 1'b0;
                wb_sel    = WB_ALU;

            end


            // ====================================================
            // MEMORY READ
            // ====================================================

            STATE_MEM_READ: begin

                mem_read  = 1'b1;
                mem_write = 1'b0;

                reg_write = 1'b0;
                wb_sel    = WB_MEM;

            end


            // ====================================================
            // MEMORY WRITE
            // ====================================================

            STATE_MEM_WRITE: begin

                mem_read  = 1'b0;
                mem_write = 1'b1;

                reg_write = 1'b0;
                wb_sel    = WB_ALU;

            end


            // ====================================================
            // WRITEBACK
            // ====================================================

            STATE_WRITEBACK: begin

                mem_read  = 1'b0;
                mem_write = 1'b0;

                reg_write = 1'b1;


                // -----------------------------------------------
                // Select writeback source
                // -----------------------------------------------

                case (execution_type)

                    // ALU instruction
                    EXEC_ALU: begin

                        wb_sel = WB_ALU;

                    end


                    // LW
                    EXEC_LOAD: begin

                        wb_sel = WB_MEM;

                    end


                    // JAL
                    EXEC_JUMP: begin

                        wb_sel = WB_PC4;

                    end


                    // Should not normally reach here
                    default: begin

                        wb_sel = WB_ALU;

                    end

                endcase

            end


            // ====================================================
            // DONE
            // ====================================================

            STATE_DONE: begin

                mem_read  = 1'b0;
                mem_write = 1'b0;

                reg_write = 1'b0;
                wb_sel    = WB_ALU;

            end


            // ====================================================
            // DEFAULT
            // ====================================================

            default: begin

                mem_read  = 1'b0;
                mem_write = 1'b0;

                reg_write = 1'b0;
                wb_sel    = WB_ALU;

            end

        endcase

    end

endmodule