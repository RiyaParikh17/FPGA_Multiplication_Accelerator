`timescale 1ns / 1ps

module pc_logic #(
    parameter WIDTH = 32
)(
    // Current PC from PC register
    input wire [WIDTH-1:0] pc,

    // Control signals
    input wire              branch_taken,
    input wire              jump,
    input wire              jalr,

    // Immediate offsets
    input wire [WIDTH-1:0]  branch_offset,
    input wire [WIDTH-1:0]  jump_offset,

    // JALR target calculated by ALU
    input wire [WIDTH-1:0]  jalr_target,

    // Generated next PC
    output reg  [WIDTH-1:0] next_pc,

    // Sequential PC value
    output wire [WIDTH-1:0] pc_plus_4
);


    // ============================================================
    // PC + 4
    // ============================================================

    assign pc_plus_4 = pc + 32'd4;


    // ============================================================
    // NEXT PC LOGIC
    // ============================================================

    always @(*) begin

        // --------------------------------------------------------
        // Default: sequential execution
        // --------------------------------------------------------

        next_pc = pc_plus_4;


        // --------------------------------------------------------
        // Conditional branch
        // --------------------------------------------------------

        if (branch_taken) begin

            next_pc = pc + branch_offset;

        end


        // --------------------------------------------------------
        // JAL
        // --------------------------------------------------------

        if (jump) begin

            next_pc = pc + jump_offset;

        end


        // --------------------------------------------------------
        // JALR
        //
        // Target = rs1 + immediate
        //
        // ALU calculates rs1 + immediate.
        // RISC V requires bit 0 of the target to be cleared.
        // --------------------------------------------------------

        if (jalr) begin

            next_pc = {jalr_target[WIDTH-1:1], 1'b0};

        end

    end

endmodule