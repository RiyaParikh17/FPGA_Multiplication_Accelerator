`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 18.08.2026 23:15:56
// Design Name: 
// Module Name: pc_register
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////



module pc_register #(
    parameter WIDTH = 32
)(
    input  wire             clk,
    input  wire             reset,
    input  wire             pc_update,

    input  wire [WIDTH-1:0] next_pc,

    output reg  [WIDTH-1:0] pc
);

    // ============================================================
    // ACTIVE LOW RESET
    //
    // reset = 0 → PC reset to 0
    // reset = 1 → normal operation
    // ============================================================

    always @(posedge clk or negedge reset) begin

        if (!reset)
            pc <= {WIDTH{1'b0}};

        else if (pc_update)
            pc <= next_pc;

    end

endmodule