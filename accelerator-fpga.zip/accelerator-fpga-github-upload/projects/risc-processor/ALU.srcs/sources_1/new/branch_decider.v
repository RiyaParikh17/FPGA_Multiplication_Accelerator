`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company:
// Engineer:
//
// Create Date: 19.08.2026
// Design Name:
// Module Name: branch_decider
// Project Name:
// Target Devices:
// Tool Versions:
// Description:
//     Determines whether a RISC V branch should be taken.
//     Uses the ALU result and branch type from the instruction decoder.
//
// Dependencies:
//     ALU
//
// Revision:
// Revision 0.01 - File Created
//////////////////////////////////////////////////////////////////////////////////


module branch_decider #(
    parameter WIDTH = 32
)(
    // ALU comparison result
    input wire [WIDTH-1:0] alu_result,

    // Branch type from instruction decoder
    input wire [2:0] branch_type,

    // Branch decision
    output reg branch_taken
);


    // ============================================================
    // BRANCH TYPES
    // ============================================================

    parameter BR_BEQ  = 3'b000;
    parameter BR_BNE  = 3'b001;
    parameter BR_BLT  = 3'b010;
    parameter BR_BGE  = 3'b011;
    parameter BR_BLTU = 3'b100;
    parameter BR_BGEU = 3'b101;
    parameter BR_NONE = 3'b111;


    // ============================================================
    // BRANCH DECISION LOGIC
    // ============================================================

    always @(*) begin

        // Default: branch not taken
        branch_taken = 1'b0;

        case (branch_type)

            // ----------------------------------------------------
            // BEQ
            // ALU performs: rs1 - rs2
            // Branch if result == 0
            // ----------------------------------------------------

            BR_BEQ: begin
                branch_taken = (alu_result == {WIDTH{1'b0}});
            end


            // ----------------------------------------------------
            // BNE
            // ALU performs: rs1 - rs2
            // Branch if result != 0
            // ----------------------------------------------------

            BR_BNE: begin
                branch_taken = (alu_result != {WIDTH{1'b0}});
            end


            // ----------------------------------------------------
            // BLT
            // ALU performs: SLT
            // Result = 1 if rs1 < rs2
            // ----------------------------------------------------

            BR_BLT: begin
                branch_taken = (alu_result == {{(WIDTH-1){1'b0}}, 1'b1});
            end


            // ----------------------------------------------------
            // BGE
            // ALU performs: SLT
            // Result = 1 if rs1 < rs2
            // Therefore BGE is taken when result == 0
            // ----------------------------------------------------

            BR_BGE: begin
                branch_taken = (alu_result == {WIDTH{1'b0}});
            end


            // ----------------------------------------------------
            // BLTU
            // ALU performs: SLTU
            // Result = 1 if rs1 < rs2 unsigned
            // ----------------------------------------------------

            BR_BLTU: begin
                branch_taken = (alu_result == {{(WIDTH-1){1'b0}}, 1'b1});
            end


            // ----------------------------------------------------
            // BGEU
            // ALU performs: SLTU
            // Result = 1 if rs1 < rs2 unsigned
            // Therefore BGEU is taken when result == 0
            // ----------------------------------------------------

            BR_BGEU: begin
                branch_taken = (alu_result == {WIDTH{1'b0}});
            end


            // ----------------------------------------------------
            // No branch
            // ----------------------------------------------------

            BR_NONE: begin
                branch_taken = 1'b0;
            end


            // ----------------------------------------------------
            // Invalid branch type
            // ----------------------------------------------------

            default: begin
                branch_taken = 1'b0;
            end

        endcase

    end

endmodule