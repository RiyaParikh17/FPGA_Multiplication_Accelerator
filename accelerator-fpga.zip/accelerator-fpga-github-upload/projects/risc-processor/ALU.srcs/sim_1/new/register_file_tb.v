`timescale 1ns/1ps

module register_file_tb;

    // Inputs
    reg clk;
    reg we;
    reg [4:0] rs1;
    reg [4:0] rs2;
    reg [4:0] rd;
    reg [31:0] wd;

    // Outputs
    wire [31:0] rd1;
    wire [31:0] rd2;
    wire [1023:0] registers_out;

    integer i;
    integer errors;

    // Instantiate Register File
    register_file uut (
        .clk(clk),
        .we(we),
        .rs1(rs1),
        .rs2(rs2),
        .rd(rd),
        .wd(wd),
        .rd1(rd1),
        .rd2(rd2),
        .registers_out(registers_out)
    );

    // Clock Generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    // Test Sequence
    initial begin

        errors = 0;

        $display("==============================================");
        $display("       REGISTER FILE TESTBENCH");
        $display("==============================================");

        // Initial values
        we  = 0;
        rs1 = 0;
        rs2 = 0;
        rd  = 0;
        wd  = 0;

        #10;

        // =====================================================
        // TEST 1: Check all registers initially zero
        // =====================================================

        $display("");
        $display("TEST 1: Checking initial register values...");

        for (i = 0; i < 32; i = i + 1) begin

            if (registers_out[i*32 +: 32] !== 32'b0) begin
                $display("ERROR: x%0d is not zero. Value = %h",
                         i, registers_out[i*32 +: 32]);
                errors = errors + 1;
            end

        end

        if (errors == 0)
            $display("PASS: All 32 registers initialized to zero.");

        // =====================================================
        // TEST 2: Write x5 = 100
        // =====================================================

        $display("");
        $display("TEST 2: Writing 100 to x5...");

        we = 1;
        rd = 5;
        wd = 32'd100;

        #10;

        if (registers_out[5*32 +: 32] === 32'd100)
            $display("PASS: x5 = %0d", registers_out[5*32 +: 32]);
        else begin
            $display("ERROR: x5 = %0d, expected 100",
                     registers_out[5*32 +: 32]);
            errors = errors + 1;
        end

        // =====================================================
        // TEST 3: Read x5
        // =====================================================

        $display("");
        $display("TEST 3: Reading x5...");

        we = 0;
        rs1 = 5;

        #1;

        if (rd1 === 32'd100)
            $display("PASS: Read x5 = %0d", rd1);
        else begin
            $display("ERROR: Read x5 = %0d, expected 100", rd1);
            errors = errors + 1;
        end

        // =====================================================
        // TEST 4: Write x10 = 200
        // =====================================================

        $display("");
        $display("TEST 4: Writing 200 to x10...");

        we = 1;
        rd = 10;
        wd = 32'd200;

        #10;

        if (registers_out[10*32 +: 32] === 32'd200)
            $display("PASS: x10 = %0d", registers_out[10*32 +: 32]);
        else begin
            $display("ERROR: x10 = %0d, expected 200",
                     registers_out[10*32 +: 32]);
            errors = errors + 1;
        end

        // =====================================================
        // TEST 5: Read x5 and x10 simultaneously
        // =====================================================

        $display("");
        $display("TEST 5: Reading x5 and x10 simultaneously...");

        we = 0;
        rs1 = 5;
        rs2 = 10;

        #1;

        if ((rd1 === 32'd100) && (rd2 === 32'd200))
            $display("PASS: x5 = %0d, x10 = %0d", rd1, rd2);
        else begin
            $display("ERROR: x5 = %0d, x10 = %0d",
                     rd1, rd2);
            errors = errors + 1;
        end

        // =====================================================
        // TEST 6: Attempt to write x0
        // =====================================================

        $display("");
        $display("TEST 6: Attempting to write 999 to x0...");

        we = 1;
        rd = 0;
        wd = 32'd999;

        #10;

        if (registers_out[0*32 +: 32] === 32'b0)
            $display("PASS: x0 remains zero.");
        else begin
            $display("ERROR: x0 changed to %0d",
                     registers_out[0*32 +: 32]);
            errors = errors + 1;
        end

        // =====================================================
        // TEST 7: Read x0
        // =====================================================

        $display("");
        $display("TEST 7: Reading x0...");

        we = 0;
        rs1 = 0;

        #1;

        if (rd1 === 32'b0)
            $display("PASS: Read x0 = 0");
        else begin
            $display("ERROR: Read x0 = %0d, expected 0", rd1);
            errors = errors + 1;
        end

        // =====================================================
        // TEST 8: Write x15 = 555
        // =====================================================

        $display("");
        $display("TEST 8: Writing 555 to x15...");

        we = 1;
        rd = 15;
        wd = 32'd555;

        #10;

        if (registers_out[15*32 +: 32] === 32'd555)
            $display("PASS: x15 = %0d",
                     registers_out[15*32 +: 32]);
        else begin
            $display("ERROR: x15 = %0d, expected 555",
                     registers_out[15*32 +: 32]);
            errors = errors + 1;
        end

        // =====================================================
        // TEST 9: Read x15 and x10
        // =====================================================

        $display("");
        $display("TEST 9: Reading x15 and x10 simultaneously...");

        we = 0;
        rs1 = 15;
        rs2 = 10;

        #1;

        if ((rd1 === 32'd555) && (rd2 === 32'd200))
            $display("PASS: x15 = %0d, x10 = %0d",
                     rd1, rd2);
        else begin
            $display("ERROR: x15 = %0d, x10 = %0d",
                     rd1, rd2);
            errors = errors + 1;
        end

        // =====================================================
        // TEST 10: Write several registers
        // =====================================================

        $display("");
        $display("TEST 10: Writing multiple registers...");

        // x1 = 10
        we = 1;
        rd = 1;
        wd = 32'd10;
        #10;

        // x2 = 20
        rd = 2;
        wd = 32'd20;
        #10;

        // x3 = 30
        rd = 3;
        wd = 32'd30;
        #10;

        // x4 = 40
        rd = 4;
        wd = 32'd40;
        #10;

        // Check all four
        if ((registers_out[1*32 +: 32] === 32'd10) &&
            (registers_out[2*32 +: 32] === 32'd20) &&
            (registers_out[3*32 +: 32] === 32'd30) &&
            (registers_out[4*32 +: 32] === 32'd40)) begin

            $display("PASS: x1 = 10");
            $display("PASS: x2 = 20");
            $display("PASS: x3 = 30");
            $display("PASS: x4 = 40");

        end
        else begin

            $display("ERROR: Multiple register write test failed.");
            errors = errors + 1;

        end

        // =====================================================
        // DISPLAY ALL 32 REGISTERS
        // =====================================================

        $display("");
        $display("==============================================");
        $display("        ALL 32 REGISTER VALUES");
        $display("==============================================");

        for (i = 0; i < 32; i = i + 1) begin
            $display("x%0d = %0d (0x%08h)",
                     i,
                     registers_out[i*32 +: 32],
                     registers_out[i*32 +: 32]);
        end

        // =====================================================
        // FINAL RESULT
        // =====================================================

        $display("");
        $display("==============================================");

        if (errors == 0)
            $display("       ALL TESTS PASSED");
        else
            $display("       TEST FAILED: %0d ERRORS", errors);

        $display("==============================================");

        $finish;

    end

endmodule