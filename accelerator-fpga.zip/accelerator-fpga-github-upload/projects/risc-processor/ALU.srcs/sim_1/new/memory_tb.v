`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 15.08.2026 15:45:49
// Design Name: 
// Module Name: memory_tb
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


`timescale 1ns / 1ps

module memory_tb;

    parameter DATA_WIDTH = 32;
    parameter ADDR_WIDTH = 10;

    reg clk;
    reg mem_read;
    reg mem_write;

    reg [ADDR_WIDTH-1:0] address;
    reg [DATA_WIDTH-1:0] write_data;

    wire [DATA_WIDTH-1:0] read_data;

    // Entire memory for debugging
    wire [(DATA_WIDTH*(1<<ADDR_WIDTH))-1:0] debug_memory;


    // Instantiate memory
    memory #(
        .DATA_WIDTH(DATA_WIDTH),
        .ADDR_WIDTH(ADDR_WIDTH)
    ) uut (
        .clk(clk),
        .mem_read(mem_read),
        .mem_write(mem_write),
        .address(address),
        .write_data(write_data),
        .read_data(read_data),
        .debug_memory(debug_memory)
    );


    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end


    // Test procedure
    initial begin

        // Initial values
        mem_read  = 0;
        mem_write = 0;
        address   = 0;
        write_data = 0;


        // Wait for simulation to start
        #10;


        // =====================================================
        // TEST 1: Write 100 to address 0
        // =====================================================

        address    = 10'd0;
        write_data = 32'd100;
        mem_write  = 1;

        #10;

        mem_write = 0;

        #1;

        if (debug_memory[31:0] == 32'd100)
            $display("TEST 1 PASSED: mem[0] = %d", debug_memory[31:0]);
        else
            $display("TEST 1 FAILED: mem[0] = %d", debug_memory[31:0]);


        // =====================================================
        // TEST 2: Write 200 to address 1
        // =====================================================

        address    = 10'd1;
        write_data = 32'd200;
        mem_write  = 1;

        #10;

        mem_write = 0;

        #1;

        if (debug_memory[63:32] == 32'd200)
            $display("TEST 2 PASSED: mem[1] = %d", debug_memory[63:32]);
        else
            $display("TEST 2 FAILED: mem[1] = %d", debug_memory[63:32]);


        // =====================================================
        // TEST 3: Write hexadecimal value to address 2
        // =====================================================

        address    = 10'd2;
        write_data = 32'hAABBCCDD;
        mem_write  = 1;

        #10;

        mem_write = 0;

        #1;

        if (debug_memory[95:64] == 32'hAABBCCDD)
            $display("TEST 3 PASSED: mem[2] = %h", debug_memory[95:64]);
        else
            $display("TEST 3 FAILED: mem[2] = %h", debug_memory[95:64]);


        // =====================================================
        // TEST 4: Read address 0
        // =====================================================

        address   = 10'd0;
        mem_read  = 1;

        #10;

        mem_read = 0;

        #1;

        if (read_data == 32'd100)
            $display("TEST 4 PASSED: read_data = %d", read_data);
        else
            $display("TEST 4 FAILED: read_data = %d", read_data);


        // =====================================================
        // TEST 5: Read address 1
        // =====================================================

        address  = 10'd1;
        mem_read = 1;

        #10;

        mem_read = 0;

        #1;

        if (read_data == 32'd200)
            $display("TEST 5 PASSED: read_data = %d", read_data);
        else
            $display("TEST 5 FAILED: read_data = %d", read_data);


        // =====================================================
        // TEST 6: Read address 2
        // =====================================================

        address  = 10'd2;
        mem_read = 1;

        #10;

        mem_read = 0;

        #1;

        if (read_data == 32'hAABBCCDD)
            $display("TEST 6 PASSED: read_data = %h", read_data);
        else
            $display("TEST 6 FAILED: read_data = %h", read_data);


        // =====================================================
        // Display memory contents
        // =====================================================

        $display("");
        $display("====================================");
        $display("MEMORY CONTENTS");
        $display("====================================");

        $display("mem[0] = %h", debug_memory[31:0]);
        $display("mem[1] = %h", debug_memory[63:32]);
        $display("mem[2] = %h", debug_memory[95:64]);

        $display("====================================");


        // Finish simulation
        #10;

        $finish;

    end

endmodule