`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 11.08.2026 15:33:31
// Design Name: 
// Module Name: immediate_generator_tb
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


`timescale 1ns/1ps

module immediate_generator_tb;

    // Inputs
    reg [31:0] instruction;
    reg [2:0]  imm_sel;

    // Output
    wire [31:0] immediate;

    // Instantiate DUT
    immediate_generator uut (
        .instruction(instruction),
        .imm_sel(imm_sel),
        .immediate(immediate)
    );

    initial begin

        $display("==============================================================");
        $display("        RISC-V IMMEDIATE GENERATOR TESTBENCH");
        $display("==============================================================");
        $display("Time\tFormat\tInstruction\t\tImmediate\tSigned");
        $display("--------------------------------------------------------------");


        // =====================================================
        // R TYPE
        // =====================================================
        // R type has no immediate
        imm_sel = 3'b000;
        instruction = 32'h003100B3;   // ADD x1, x2, x3

        #10;

        $display("%0t\tR\t%h\t%h\t%d",
                 $time, instruction, immediate, $signed(immediate));


        // =====================================================
        // I TYPE - Positive immediate
        // =====================================================
        // ADDI x5, x2, 10
        //
        // Immediate = 10
        //
        imm_sel = 3'b001;
        instruction = 32'h00A10293;

        #10;

        $display("%0t\tI\t%h\t%h\t%d",
                 $time, instruction, immediate, $signed(immediate));


        // =====================================================
        // I TYPE - Negative immediate
        // =====================================================
        // Test immediate = -1
        //
        imm_sel = 3'b001;
        instruction = 32'hFFF10293;

        #10;

        $display("%0t\tI\t%h\t%h\t%d",
                 $time, instruction, immediate, $signed(immediate));


        // =====================================================
        // S TYPE
        // =====================================================
        // SW x5, 20(x2)
        //
        // Immediate = 20
        //
        imm_sel = 3'b010;
        instruction = 32'h00512A23;

        #10;

        $display("%0t\tS\t%h\t%h\t%d",
                 $time, instruction, immediate, $signed(immediate));


        // =====================================================
        // B TYPE
        // =====================================================
        // BEQ x1, x2, 16
        //
        // Immediate = 16
        //
        imm_sel = 3'b011;
        instruction = 32'h00208863;

        #10;

        $display("%0t\tB\t%h\t%h\t%d",
                 $time, instruction, immediate, $signed(immediate));


        // =====================================================
        // U TYPE
        // =====================================================
        // LUI x5, 0x12345
        //
        // Immediate = 0x12345000
        //
        imm_sel = 3'b100;
        instruction = 32'h123452B7;

        #10;

        $display("%0t\tU\t%h\t%h\t%h",
                 $time, instruction, immediate, immediate);


        // =====================================================
        // J TYPE
        // =====================================================
        // JAL x1, 16
        //
        // Immediate = 16
        //
        imm_sel = 3'b101;
        instruction = 32'h010000EF;

        #10;

        $display("%0t\tJ\t%h\t%h\t%d",
                 $time, instruction, immediate, $signed(immediate));


        // =====================================================
        // END
        // =====================================================

        $display("--------------------------------------------------------------");
        $display("TESTBENCH COMPLETE");
        $display("==============================================================");

        $finish;

    end

endmodule