`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 18.08.2026 15:19:50
// Design Name: 
// Module Name: instruction_memory_tb
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module instruction_memory_tb;

    // =========================================================
    // Signals
    // =========================================================

    reg         clk;
    reg  [31:0] pc;

    wire [31:0] instruction;

    wire [32767:0] debug_memory;


    // =========================================================
    // DUT
    // =========================================================

    instruction_memory uut (
        .clk(clk),
        .pc(pc),
        .instruction(instruction),
        .debug_memory(debug_memory)
    );


    // =========================================================
    // Clock
    // 10 ns period
    // =========================================================

    initial begin
        clk = 0;

        forever #5 clk = ~clk;
    end


    // =========================================================
    // Test
    // =========================================================

    initial begin

        pc = 32'h00000000;

        // Wait for memory initialization
        #2;


        // =====================================================
        // TEST 1
        // PC = 0
        // Expected: ADDI x1, x0, 100
        // =====================================================

        pc = 32'h00000000;

        @(posedge clk);
        #1;

        $display("");
        $display("==============================================");
        $display("TEST 1: PC = 0");
        $display("==============================================");

        $display("PC          = %h", pc);
        $display("instruction = %h", instruction);

        if (instruction == 32'h06400093)
            $display("TEST 1 PASSED");
        else
            $display("TEST 1 FAILED");


        // =====================================================
        // TEST 2
        // PC = 4
        // Expected: ADDI x2, x0, 1234
        // =====================================================

        pc = 32'h00000004;

        @(posedge clk);
        #1;

        $display("");
        $display("==============================================");
        $display("TEST 2: PC = 4");
        $display("==============================================");

        $display("PC          = %h", pc);
        $display("instruction = %h", instruction);

        if (instruction == 32'h4D200113)
            $display("TEST 2 PASSED");
        else
            $display("TEST 2 FAILED");


        // =====================================================
        // TEST 3
        // PC = 8
        // Expected: SW x2, 8(x1)
        // =====================================================

        pc = 32'h00000008;

        @(posedge clk);
        #1;

        $display("");
        $display("==============================================");
        $display("TEST 3: PC = 8");
        $display("==============================================");

        $display("PC          = %h", pc);
        $display("instruction = %h", instruction);

        if (instruction == 32'h0020A423)
            $display("TEST 3 PASSED");
        else
            $display("TEST 3 FAILED");


        // =====================================================
        // TEST 4
        // PC = 12
        // Expected: LW x3, 8(x1)
        // =====================================================

        pc = 32'h0000000C;

        @(posedge clk);
        #1;

        $display("");
        $display("==============================================");
        $display("TEST 4: PC = 12");
        $display("==============================================");

        $display("PC          = %h", pc);
        $display("instruction = %h", instruction);

        if (instruction == 32'h0080A183)
            $display("TEST 4 PASSED");
        else
            $display("TEST 4 FAILED");


        // =====================================================
        // TEST 5
        // PC = 16
        // Expected: NOP
        // =====================================================

        pc = 32'h00000010;

        @(posedge clk);
        #1;

        $display("");
        $display("==============================================");
        $display("TEST 5: PC = 16");
        $display("==============================================");

        $display("PC          = %h", pc);
        $display("instruction = %h", instruction);

        if (instruction == 32'h00000013)
            $display("TEST 5 PASSED");
        else
            $display("TEST 5 FAILED");


        // =====================================================
        // TEST 6
        // Check debug memory
        // =====================================================

        $display("");
        $display("==============================================");
        $display("TEST 6: DEBUG MEMORY");
        $display("==============================================");

        $display("memory[0] = %h",
                 debug_memory[0*32 +: 32]);

        $display("memory[1] = %h",
                 debug_memory[1*32 +: 32]);

        $display("memory[2] = %h",
                 debug_memory[2*32 +: 32]);

        $display("memory[3] = %h",
                 debug_memory[3*32 +: 32]);


        if ((debug_memory[0*32 +: 32] == 32'h06400093) &&
            (debug_memory[1*32 +: 32] == 32'h4D200113) &&
            (debug_memory[2*32 +: 32] == 32'h0020A423) &&
            (debug_memory[3*32 +: 32] == 32'h0080A183))
            
            $display("TEST 6 PASSED");
        else
            $display("TEST 6 FAILED");


        // =====================================================
        // FINAL
        // =====================================================

        $display("");
        $display("==============================================");
        $display("INSTRUCTION MEMORY TEST COMPLETE");
        $display("==============================================");

        #10;

        $finish;

    end

endmodule