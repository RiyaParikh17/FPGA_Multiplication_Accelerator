`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 02.08.2026 16:15:11
// Design Name: 
// Module Name: alu_tb
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


`timescale 1ns/1ps

module alu_tb;

    // Inputs
    reg  [31:0] a;
    reg  [31:0] b;
    reg  [3:0]  alu_ctrl;

    // Outputs
    wire [31:0] result;
    wire zero;

    // Instantiate the ALU
    alu uut (
        .a(a),
        .b(b),
        .alu_ctrl(alu_ctrl),
        .result(result),
        .zero(zero)
    );

    initial begin

        $display("---------------------------------------------------------");
        $display(" Time | Ctrl |     A     |     B     |  Result  | Zero");
        $display("---------------------------------------------------------");

        // ADD
        a = 20; b = 10; alu_ctrl = 4'b0000;
        #10;
        $display("%4t | ADD  | %8d | %8d | %8d | %b",
                  $time, a, b, result, zero);

        // SUB
        a = 20; b = 10; alu_ctrl = 4'b0001;
        #10;
        $display("%4t | SUB  | %8d | %8d | %8d | %b",
                  $time, a, b, result, zero);

        // AND
        a = 32'hF0F0F0F0;
        b = 32'h0F0F0F0F;
        alu_ctrl = 4'b0010;
        #10;
        $display("%4t | AND  | %h | %h | %h | %b",
                  $time, a, b, result, zero);

        // OR
        alu_ctrl = 4'b0011;
        #10;
        $display("%4t | OR   | %h | %h | %h | %b",
                  $time, a, b, result, zero);

        // XOR
        alu_ctrl = 4'b0100;
        #10;
        $display("%4t | XOR  | %h | %h | %h | %b",
                  $time, a, b, result, zero);

        // SLL
        a = 5;
        b = 2;
        alu_ctrl = 4'b0101;
        #10;
        $display("%4t | SLL  | %8d | %8d | %8d | %b",
                  $time, a, b, result, zero);

        // SRL
        a = 32;
        b = 2;
        alu_ctrl = 4'b0110;
        #10;
        $display("%4t | SRL  | %8d | %8d | %8d | %b",
                  $time, a, b, result, zero);

        // SRA
        a = -16;
        b = 2;
        alu_ctrl = 4'b0111;
        #10;
        $display("%4t | SRA  | %8d | %8d | %8d | %b",
                  $time, $signed(a), b, $signed(result), zero);

        // SLT
        a = -5;
        b = 3;
        alu_ctrl = 4'b1000;
        #10;
        $display("%4t | SLT  | %8d | %8d | %8d | %b",
                  $time, $signed(a), $signed(b), result, zero);

        // SLTU
        a = 32'hFFFFFFFF;
        b = 1;
        alu_ctrl = 4'b1001;
        #10;
        $display("%4t | SLTU | %h | %h | %d | %b",
                  $time, a, b, result, zero);

        // Zero flag test
        a = 50;
        b = 50;
        alu_ctrl = 4'b0001;
        #10;
        $display("%4t | ZERO | %8d | %8d | %8d | %b",
                  $time, a, b, result, zero);

        $display("---------------------------------------------------------");

        $finish;

    end

endmodule