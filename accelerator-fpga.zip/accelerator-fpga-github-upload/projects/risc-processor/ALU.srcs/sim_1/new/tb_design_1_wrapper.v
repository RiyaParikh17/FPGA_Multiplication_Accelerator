`timescale 1ns / 1ps

module design_1_wrapper_tb;

    // ============================================================
    // INPUTS
    // ============================================================

    reg clk_100MHz;
    reg reset_rtl_0;


    // ============================================================
    // REQUIRED OUTPUTS ONLY
    // ============================================================

    wire [2:0]     state;
    wire [4:0]     rd;
    wire [31:0]    result_0;
    wire [31:0]    writeback_data;
    wire           reg_write;

    wire [1023:0]  registers_out;

    // Instruction memory debug
    wire [32767:0] debug_memory_0;


    // ============================================================
    // DUT
    // ============================================================

    design_1_wrapper DUT (

        .clk_100MHz(clk_100MHz),
        .reset_rtl_0(reset_rtl_0),

        .state(state),
        .rd(rd),
        .result_0(result_0),
        .writeback_data(writeback_data),
        .reg_write(reg_write),

        .registers_out(registers_out),

        .debug_memory_0(debug_memory_0)

    );


    // ============================================================
    // 100 MHz CLOCK
    // ============================================================

    initial begin

        clk_100MHz = 1'b0;

        forever #5 clk_100MHz = ~clk_100MHz;

    end


    // ============================================================
    // DISPLAY REGISTERS
    // ============================================================

    task display_registers;

        begin

            $display(
                "x1=%0d | x2=%0d | x3=%0d | x5=%0d",
                registers_out[63:32],
                registers_out[95:64],
                registers_out[127:96],
                registers_out[191:160]
            );

        end

    endtask


    // ============================================================
    // TEST
    // ============================================================

    initial begin

        // ========================================================
        // ACTIVE LOW RESET
        // ========================================================

        reset_rtl_0 = 1'b0;

        #20;

        reset_rtl_0 = 1'b1;


        // ========================================================
        // DISPLAY PROGRAM
        // ========================================================

        $display("");
        $display("==============================================");
        $display("JALR TEST PROGRAM");
        $display("==============================================");

        $display("mem[0] = %h", debug_memory_0[31:0]);
        $display("mem[1] = %h", debug_memory_0[63:32]);
        $display("mem[2] = %h", debug_memory_0[95:64]);
        $display("mem[3] = %h", debug_memory_0[127:96]);
        $display("mem[4] = %h", debug_memory_0[159:128]);
        $display("mem[5] = %h", debug_memory_0[191:160]);
        $display("mem[6] = %h", debug_memory_0[223:192]);
        $display("mem[7] = %h", debug_memory_0[255:224]);

        $display("==============================================");


        // ========================================================
        // RUN PROCESSOR
        // ========================================================

        $display("");
        $display("PROCESSOR START");
        $display("");


        repeat (35) begin

            @(posedge clk_100MHz);

            #1;

            $display(
                "Time=%0t | State=%b | RD=x%0d | Result=%0d | WB=%0d | RegWrite=%b",
                $time,
                state,
                rd,
                result_0,
                writeback_data,
                reg_write
            );

            display_registers();

        end


        // ========================================================
        // FINAL RESULTS
        // ========================================================

        $display("");
        $display("==============================================");
        $display("FINAL RESULTS");
        $display("==============================================");

        display_registers();


        // ========================================================
        // CHECK x1
        //
        // ADDI x1, x0, 20
        //
        // x1 = 20
        // ========================================================

        if (registers_out[63:32] == 32'd20)

            $display("PASS: x1 = 20");

        else

            $display(
                "FAIL: x1 expected 20, got %0d",
                registers_out[63:32]
            );


        // ========================================================
        // CHECK x2
        //
        // Instructions at PC = 8, 12, 16, 20 and 24
        // should all be skipped.
        //
        // Therefore x2 must remain 0.
        // ========================================================

        if (registers_out[95:64] == 32'd0)

            $display("PASS: x2 = 0, instructions skipped");

        else

            $display(
                "FAIL: x2 should be 0, got %0d",
                registers_out[95:64]
            );


        // ========================================================
        // CHECK x3
        //
        // PC = 28
        //
        // ADDI x3, x0, 30
        //
        // This is the JALR target.
        // ========================================================

        if (registers_out[127:96] == 32'd30)

            $display("PASS: x3 = 30, JALR target executed");

        else

            $display(
                "FAIL: x3 expected 30, got %0d",
                registers_out[127:96]
            );


        // ========================================================
        // CHECK x5
        //
        // JALR is at PC = 4
        //
        // x5 = PC + 4
        //    = 4 + 4
        //    = 8
        // ========================================================

        if (registers_out[191:160] == 32'd8)

            $display("PASS: x5 = 8, JALR link address correct");

        else

            $display(
                "FAIL: x5 expected 8, got %0d",
                registers_out[191:160]
            );


        // ========================================================
        // COMPLETE
        // ========================================================

        $display("");
        $display("==============================================");
        $display("JALR TEST COMPLETE");
        $display("==============================================");

        #20;

        $finish;

    end

endmodule