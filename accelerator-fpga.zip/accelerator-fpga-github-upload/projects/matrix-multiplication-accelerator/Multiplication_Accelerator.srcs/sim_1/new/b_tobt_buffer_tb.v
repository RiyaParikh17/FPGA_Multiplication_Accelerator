`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 27.08.2026 21:26:44
// Design Name: 
// Module Name: b_tobt_buffer_tb
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


`timescale 1ns / 1ps

module b_to_bt_buffer_tb;

    // Parameters
    parameter DATA_WIDTH = 32;

    // Clock and reset
    reg clk;
    reg reset;

    // Buffer inputs
    reg                  buffer_load;
    reg [1:0]            row_select;
    reg [DATA_WIDTH-1:0] buffer_data;
    reg                  buffer_clear;

    // Buffer outputs
    wire [DATA_WIDTH-1:0] buf0;
    wire [DATA_WIDTH-1:0] buf1;
    wire [DATA_WIDTH-1:0] buf2;
    wire [DATA_WIDTH-1:0] buf3;

    wire buffer_full;

    // =========================================================
    // DUT
    // =========================================================

    b_to_bt_buffer #(
        .DATA_WIDTH(DATA_WIDTH)
    ) dut (
        .clk          (clk),
        .reset        (reset),

        .buffer_load  (buffer_load),
        .row_select   (row_select),
        .buffer_data  (buffer_data),

        .buffer_clear (buffer_clear),

        .buf0         (buf0),
        .buf1         (buf1),
        .buf2         (buf2),
        .buf3         (buf3),

        .buffer_full  (buffer_full)
    );

    // =========================================================
    // Clock
    // =========================================================

    initial begin
        clk = 1'b0;

        forever #5 clk = ~clk;
    end

    // =========================================================
    // Test
    // =========================================================

    initial begin

        // Initial values
        reset        = 1'b1;
        buffer_load  = 1'b0;
        row_select   = 2'b00;
        buffer_data  = 32'b0;
        buffer_clear = 1'b0;

        // Reset
        #20;
        reset = 1'b0;

        // -----------------------------------------------------
        // Row 0
        // B00 B01 B02 B03
        // -----------------------------------------------------

        @(negedge clk);

        buffer_load = 1'b1;
        row_select  = 2'd0;
        buffer_data = 32'h04030201;

        @(negedge clk);

        // -----------------------------------------------------
        // Row 1
        // B10 B11 B12 B13
        // -----------------------------------------------------

        row_select  = 2'd1;
        buffer_data = 32'h14131211;

        @(negedge clk);

        // -----------------------------------------------------
        // Row 2
        // B20 B21 B22 B23
        // -----------------------------------------------------

        row_select  = 2'd2;
        buffer_data = 32'h24232221;

        @(negedge clk);

        // -----------------------------------------------------
        // Row 3
        // B30 B31 B32 B33
        // -----------------------------------------------------

        row_select  = 2'd3;
        buffer_data = 32'h34333231;

        @(negedge clk);

        // Stop loading
        buffer_load = 1'b0;

        // Allow outputs to settle
        @(posedge clk);

        // =====================================================
        // Display results
        // =====================================================

        $display("---------------------------------------------");
        $display("BUFFER TEST RESULTS");
        $display("---------------------------------------------");

        $display("buf0 = %h", buf0);
        $display("buf1 = %h", buf1);
        $display("buf2 = %h", buf2);
        $display("buf3 = %h", buf3);

        $display("buffer_full = %b", buffer_full);

        // =====================================================
        // Verification
        // =====================================================

        if (buf0 !== 32'h31211101) begin
            $display("FAIL: buf0 incorrect");
        end
        else begin
            $display("PASS: buf0");
        end

        if (buf1 !== 32'h32221202) begin
            $display("FAIL: buf1 incorrect");
        end
        else begin
            $display("PASS: buf1");
        end

        if (buf2 !== 32'h33231303) begin
            $display("FAIL: buf2 incorrect");
        end
        else begin
            $display("PASS: buf2");
        end

        if (buf3 !== 32'h34241404) begin
            $display("FAIL: buf3 incorrect");
        end
        else begin
            $display("PASS: buf3");
        end

        if (buffer_full !== 1'b1) begin
            $display("FAIL: buffer_full not asserted");
        end
        else begin
            $display("PASS: buffer_full");
        end

        // =====================================================
        // Clear test
        // =====================================================

        @(negedge clk);

        buffer_clear = 1'b1;

        @(negedge clk);

        buffer_clear = 1'b0;

        @(posedge clk);

        $display("---------------------------------------------");
        $display("AFTER CLEAR");
        $display("---------------------------------------------");

        $display("buf0 = %h", buf0);
        $display("buf1 = %h", buf1);
        $display("buf2 = %h", buf2);
        $display("buf3 = %h", buf3);
        $display("buffer_full = %b", buffer_full);

        if ((buf0 === 32'b0) &&
            (buf1 === 32'b0) &&
            (buf2 === 32'b0) &&
            (buf3 === 32'b0) &&
            (buffer_full === 1'b0)) begin

            $display("PASS: BUFFER CLEAR");

        end
        else begin

            $display("FAIL: BUFFER CLEAR");

        end

        $display("---------------------------------------------");
        $display("BUFFER TEST COMPLETE");
        $display("---------------------------------------------");

        $finish;

    end

endmodule