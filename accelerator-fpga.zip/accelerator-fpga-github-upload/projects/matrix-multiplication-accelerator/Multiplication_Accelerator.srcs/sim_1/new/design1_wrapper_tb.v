`timescale 1ns / 1ps

module design1_wrapper_tb;

    // =====================================================
    // INPUTS
    // =====================================================

    reg [9:0]  BT_base_0;
    reg [9:0]  B_base_0;
    reg [15:0] B_cols_0;
    reg [15:0] B_rows_0;

    reg        clk_100MHz;
    reg [9:0]  rd_addr_0;

    reg        reset_0;
    reg        start_0;


    // =====================================================
    // OUTPUTS
    // =====================================================

    wire        BT_we;
    wire [9:0]  BT_wr_addr_0;

    wire [31:0] buf0;
    wire [31:0] buf1;
    wire [31:0] buf2;
    wire [31:0] buf3;

    wire        buffer_full;
    wire [3:0]  buffer_select;

    wire        busy_0;

    wire [15:0] debug_B_col_group_0;
    wire [15:0] debug_B_row_0;
    wire [9:0]  debug_current_B_addr_0;

    wire [32767:0] debug_memory_0;

    wire        done_0;

    wire [9:0]  mainmem_addr;
    wire [31:0] mainmemory_read_data;
    wire        mem_rvalid;

    wire [31:0] rd_data_0;

    wire [1:0]  row_select;

    wire [3:0]  state_0;

    wire [31:0] wr_data;


    // =====================================================
    // DUT
    // =====================================================

    design_1_wrapper dut (

        .BT_base_0(BT_base_0),
        .BT_we(BT_we),
        .BT_wr_addr_0(BT_wr_addr_0),

        .B_base_0(B_base_0),
        .B_cols_0(B_cols_0),
        .B_rows_0(B_rows_0),

        .buf0(buf0),
        .buf1(buf1),
        .buf2(buf2),
        .buf3(buf3),

        .buffer_full(buffer_full),
        .buffer_select(buffer_select),

        .busy_0(busy_0),

        .clk_100MHz(clk_100MHz),

        .debug_B_col_group_0(debug_B_col_group_0),
        .debug_B_row_0(debug_B_row_0),
        .debug_current_B_addr_0(debug_current_B_addr_0),

        .debug_memory_0(debug_memory_0),

        .done_0(done_0),

        .mainmem_addr(mainmem_addr),
        .mainmemory_read_data(mainmemory_read_data),
        .mem_rvalid(mem_rvalid),

        .rd_addr_0(rd_addr_0),
        .rd_data_0(rd_data_0),

        .reset_0(reset_0),

        .row_select(row_select),

        .start_0(start_0),

        .state_0(state_0),

        .wr_data(wr_data)
    );


    // =====================================================
    // 100 MHz CLOCK
    // =====================================================

    initial begin

        clk_100MHz = 1'b0;

        forever #5 clk_100MHz = ~clk_100MHz;

    end


    // =====================================================
    // TEST
    // =====================================================

    initial begin

        // -------------------------------------------------
        // INITIALIZATION
        // -------------------------------------------------

        BT_base_0 = 10'd64;

        B_base_0  = 10'd0;

        B_rows_0  = 16'd8;
        B_cols_0  = 16'd8;

        rd_addr_0 = 10'd0;

        reset_0 = 1'b0;
        start_0 = 1'b0;


        // -------------------------------------------------
        // RESET
        // -------------------------------------------------

        $display("");
        $display("======================================");
        $display("APPLYING ACTIVE LOW RESET");
        $display("======================================");

        #20;

        reset_0 = 1'b1;

        $display("[%0t ns] Reset released", $time);


        // -------------------------------------------------
        // START
        // -------------------------------------------------

        @(negedge clk_100MHz);

        start_0 = 1'b1;

        $display("[%0t ns] START asserted", $time);

        @(negedge clk_100MHz);

        start_0 = 1'b0;

        $display("[%0t ns] START deasserted", $time);


        // -------------------------------------------------
        // WAIT UNTIL DONE
        // -------------------------------------------------

        wait(done_0 == 1'b1);

        #10;

        $display("");
        $display("======================================");
        $display("ACCELERATOR DONE");
        $display("======================================");


        #20;

        $finish;

    end


    // =====================================================
    // PRINT BT BRAM WHEN NEXT_GROUP IS REACHED
    // =====================================================

    // NEXT_GROUP = 4'd8

    always @(posedge clk_100MHz) begin

        if (reset_0 && state_0 == 4'd8) begin

            $display("");
            $display("======================================");
            $display("BT BRAM CONTENT");
            $display("======================================");

            $display(
                "BT WORD 0  | Byte Addr = 64  | Data = %h",
                debug_memory_0[16*32 +: 32]
            );

            $display(
                "BT WORD 1  | Byte Addr = 68  | Data = %h",
                debug_memory_0[17*32 +: 32]
            );

            $display(
                "BT WORD 2  | Byte Addr = 72  | Data = %h",
                debug_memory_0[18*32 +: 32]
            );

            $display(
                "BT WORD 3  | Byte Addr = 76  | Data = %h",
                debug_memory_0[19*32 +: 32]
            );

            $display(
                "BT WORD 4  | Byte Addr = 80  | Data = %h",
                debug_memory_0[20*32 +: 32]
            );

            $display(
                "BT WORD 5  | Byte Addr = 84  | Data = %h",
                debug_memory_0[21*32 +: 32]
            );

            $display(
                "BT WORD 6  | Byte Addr = 88  | Data = %h",
                debug_memory_0[22*32 +: 32]
            );

            $display(
                "BT WORD 7  | Byte Addr = 92  | Data = %h",
                debug_memory_0[23*32 +: 32]
            );

            $display(
                "BT WORD 8  | Byte Addr = 96  | Data = %h",
                debug_memory_0[24*32 +: 32]
            );

            $display(
                "BT WORD 9  | Byte Addr = 100 | Data = %h",
                debug_memory_0[25*32 +: 32]
            );

            $display(
                "BT WORD 10 | Byte Addr = 104 | Data = %h",
                debug_memory_0[26*32 +: 32]
            );

            $display(
                "BT WORD 11 | Byte Addr = 108 | Data = %h",
                debug_memory_0[27*32 +: 32]
            );

            $display(
                "BT WORD 12 | Byte Addr = 112 | Data = %h",
                debug_memory_0[28*32 +: 32]
            );

            $display(
                "BT WORD 13 | Byte Addr = 116 | Data = %h",
                debug_memory_0[29*32 +: 32]
            );

            $display(
                "BT WORD 14 | Byte Addr = 120 | Data = %h",
                debug_memory_0[30*32 +: 32]
            );

            $display(
                "BT WORD 15 | Byte Addr = 124 | Data = %h",
                debug_memory_0[31*32 +: 32]
            );

            $display("======================================");

        end

    end

endmodule