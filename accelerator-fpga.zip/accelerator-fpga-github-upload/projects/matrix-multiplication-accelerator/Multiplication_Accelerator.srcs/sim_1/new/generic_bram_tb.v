`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 03.09.2026 15:25:41
// Design Name: 
// Module Name: generic_bram_tb
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module generic_bram_tb;

    // =========================================================
    // PARAMETERS
    // =========================================================

    localparam DATA_WIDTH = 32;
    localparam ADDR_WIDTH = 10;

    localparam CLK_PERIOD = 10;


    // =========================================================
    // SIGNALS
    // =========================================================

    reg clk;

    reg                         we;
    reg [ADDR_WIDTH-1:0]        wr_addr;
    reg [DATA_WIDTH-1:0]        wr_data;

    reg [ADDR_WIDTH-1:0]        rd_addr;
    wire [DATA_WIDTH-1:0]       rd_data;

    wire [(DATA_WIDTH*(1<<ADDR_WIDTH))-1:0] debug_memory;


    // =========================================================
    // DUT
    // =========================================================

    generic_bram #(
        .DATA_WIDTH(DATA_WIDTH),
        .ADDR_WIDTH(ADDR_WIDTH)
    ) dut (

        .clk(clk),

        .we(we),
        .wr_addr(wr_addr),
        .wr_data(wr_data),

        .rd_addr(rd_addr),
        .rd_data(rd_data),

        .debug_memory(debug_memory)

    );


    // =========================================================
    // 100 MHz CLOCK
    // =========================================================

    initial begin
        clk = 1'b0;

        forever #(CLK_PERIOD/2) clk = ~clk;
    end


    // =========================================================
    // TEST
    // =========================================================

    initial begin

        // -----------------------------------------------------
        // Initial values
        // -----------------------------------------------------

        we      = 1'b0;
        wr_addr = 10'd0;
        wr_data = 32'd0;

        rd_addr = 10'd0;


        // -----------------------------------------------------
        // Wait for clock alignment
        // -----------------------------------------------------

        #20;


        // =====================================================
        // WRITE TEST
        // =====================================================

        $display("");
        $display("======================================");
        $display("BRAM WRITE TEST");
        $display("======================================");


        // -----------------------------------------------------
        // Write 1
        // Address = 64
        // Data    = 0D090501
        // -----------------------------------------------------

        @(negedge clk);

        we      = 1'b1;
        wr_addr = 10'd64;
        wr_data = 32'h0D090501;

        @(posedge clk);

        #1;

        $display(
            "[%0t ns] WRITE | Addr = %0d | Data = %h",
            $time,
            wr_addr,
            wr_data
        );


        // -----------------------------------------------------
        // Write 2
        // Address = 68
        // Data    = 0E0A0602
        // -----------------------------------------------------

        @(negedge clk);

        wr_addr = 10'd68;
        wr_data = 32'h0E0A0602;

        @(posedge clk);

        #1;

        $display(
            "[%0t ns] WRITE | Addr = %0d | Data = %h",
            $time,
            wr_addr,
            wr_data
        );


        // -----------------------------------------------------
        // Write 3
        // Address = 72
        // Data    = 0F0B0703
        // -----------------------------------------------------

        @(negedge clk);

        wr_addr = 10'd72;
        wr_data = 32'h0F0B0703;

        @(posedge clk);

        #1;

        $display(
            "[%0t ns] WRITE | Addr = %0d | Data = %h",
            $time,
            wr_addr,
            wr_data
        );


        // -----------------------------------------------------
        // Write 4
        // Address = 76
        // Data    = 100C0804
        // -----------------------------------------------------

        @(negedge clk);

        wr_addr = 10'd76;
        wr_data = 32'h100C0804;

        @(posedge clk);

        #1;

        $display(
            "[%0t ns] WRITE | Addr = %0d | Data = %h",
            $time,
            wr_addr,
            wr_data
        );


        // -----------------------------------------------------
        // Disable write
        // -----------------------------------------------------

        @(negedge clk);

        we      = 1'b0;
        wr_addr = 10'd0;
        wr_data = 32'd0;


        // =====================================================
        // DIRECT DEBUG MEMORY CHECK
        // =====================================================

        #1;

        $display("");
        $display("======================================");
        $display("DIRECT DEBUG MEMORY CHECK");
        $display("======================================");

        $display(
            "debug_memory[64] = %h",
            debug_memory[64*32 +: 32]
        );

        $display(
            "debug_memory[68] = %h",
            debug_memory[68*32 +: 32]
        );

        $display(
            "debug_memory[72] = %h",
            debug_memory[72*32 +: 32]
        );

        $display(
            "debug_memory[76] = %h",
            debug_memory[76*32 +: 32]
        );


        // =====================================================
        // READ TEST
        // =====================================================

        $display("");
        $display("======================================");
        $display("BRAM READ TEST");
        $display("======================================");


        // -----------------------------------------------------
        // Read address 64
        // -----------------------------------------------------

        @(negedge clk);

        rd_addr = 10'd64;

        @(posedge clk);

        #1;

        $display(
            "[%0t ns] READ | Addr = %0d | Data = %h | Expected = 0D090501",
            $time,
            rd_addr,
            rd_data
        );

        if (rd_data === 32'h0D090501)
            $display("       PASS");
        else
            $display("       FAIL");


        // -----------------------------------------------------
        // Read address 68
        // -----------------------------------------------------

        @(negedge clk);

        rd_addr = 10'd68;

        @(posedge clk);

        #1;

        $display(
            "[%0t ns] READ | Addr = %0d | Data = %h | Expected = 0E0A0602",
            $time,
            rd_addr,
            rd_data
        );

        if (rd_data === 32'h0E0A0602)
            $display("       PASS");
        else
            $display("       FAIL");


        // -----------------------------------------------------
        // Read address 72
        // -----------------------------------------------------

        @(negedge clk);

        rd_addr = 10'd72;

        @(posedge clk);

        #1;

        $display(
            "[%0t ns] READ | Addr = %0d | Data = %h | Expected = 0F0B0703",
            $time,
            rd_addr,
            rd_data
        );

        if (rd_data === 32'h0F0B0703)
            $display("       PASS");
        else
            $display("       FAIL");


        // -----------------------------------------------------
        // Read address 76
        // -----------------------------------------------------

        @(negedge clk);

        rd_addr = 10'd76;

        @(posedge clk);

        #1;

        $display(
            "[%0t ns] READ | Addr = %0d | Data = %h | Expected = 100C0804",
            $time,
            rd_addr,
            rd_data
        );

        if (rd_data === 32'h100C0804)
            $display("       PASS");
        else
            $display("       FAIL");


        // =====================================================
        // FINAL DEBUG CHECK
        // =====================================================

        $display("");
        $display("======================================");
        $display("FINAL DEBUG MEMORY CHECK");
        $display("======================================");

        if (
            debug_memory[64*32 +: 32] === 32'h0D090501 &&
            debug_memory[68*32 +: 32] === 32'h0E0A0602 &&
            debug_memory[72*32 +: 32] === 32'h0F0B0703 &&
            debug_memory[76*32 +: 32] === 32'h100C0804
        ) begin

            $display("DEBUG MEMORY CHECK: PASS");

        end
        else begin

            $display("DEBUG MEMORY CHECK: FAIL");

        end


        $display("");
        $display("======================================");
        $display("SIMULATION COMPLETE");
        $display("======================================");


        #20;

        $finish;

    end

endmodule