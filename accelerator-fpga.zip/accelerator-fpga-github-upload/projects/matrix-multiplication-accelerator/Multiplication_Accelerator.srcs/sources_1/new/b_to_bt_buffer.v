`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 27.08.2026 21:21:45
// Design Name: 
// Module Name: b_to_bt_buffer
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module b_to_bt_buffer #(
    parameter DATA_WIDTH = 32
)(
    input  wire                  clk,
    input  wire                  reset,

    // Load one 32-bit word from main memory
    input  wire                  buffer_load,
    input  wire [1:0]            row_select,
    input  wire [DATA_WIDTH-1:0] buffer_data,

    // Clear buffers after writing to BT BRAM
    input  wire                  buffer_clear,

    // Four completed BT words
    output reg  [DATA_WIDTH-1:0] buf0,
    output reg  [DATA_WIDTH-1:0] buf1,
    output reg  [DATA_WIDTH-1:0] buf2,
    output reg  [DATA_WIDTH-1:0] buf3,

    // Indicates that all four rows have been loaded
    output reg                   buffer_full
);

    always @(posedge clk) begin

        if (!reset) begin

            buf0        <= 32'b0;
            buf1        <= 32'b0;
            buf2        <= 32'b0;
            buf3        <= 32'b0;
            buffer_full <= 1'b0;

        end
        else if (buffer_clear) begin

            buf0        <= 32'b0;
            buf1        <= 32'b0;
            buf2        <= 32'b0;
            buf3        <= 32'b0;
            buffer_full <= 1'b0;

        end
        else if (buffer_load) begin

            case (row_select)

                2'd0: begin
                    buf0[7:0]   <= buffer_data[7:0];
                    buf1[7:0]   <= buffer_data[15:8];
                    buf2[7:0]   <= buffer_data[23:16];
                    buf3[7:0]   <= buffer_data[31:24];
                end

                2'd1: begin
                    buf0[15:8]  <= buffer_data[7:0];
                    buf1[15:8]  <= buffer_data[15:8];
                    buf2[15:8]  <= buffer_data[23:16];
                    buf3[15:8]  <= buffer_data[31:24];
                end

                2'd2: begin
                    buf0[23:16] <= buffer_data[7:0];
                    buf1[23:16] <= buffer_data[15:8];
                    buf2[23:16] <= buffer_data[23:16];
                    buf3[23:16] <= buffer_data[31:24];
                end

                2'd3: begin
                    buf0[31:24] <= buffer_data[7:0];
                    buf1[31:24] <= buffer_data[15:8];
                    buf2[31:24] <= buffer_data[23:16];
                    buf3[31:24] <= buffer_data[31:24];

                    buffer_full <= 1'b1;
                end

            endcase

        end

    end

endmodule