
`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 27.08.2026 21:48:40
// Design Name: 
// Module Name: b_to_buffer_controller
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module b_to_bt_controller #(
    parameter ADDR_WIDTH = 32
)(
    input  wire                     clk,
    input  wire                     reset,

    // =========================================================
    // Matrix configuration
    // B = i x j
    // =========================================================

    input  wire                     start,

    input  wire [ADDR_WIDTH-1:0]    B_base,
    input  wire [ADDR_WIDTH-1:0]    BT_base,

    input  wire [15:0]              B_rows,       // i
    input  wire [15:0]              B_cols,       // j


    // =========================================================
    // Main memory control interface
    //
    // mem_rdata is NOT connected to controller.
    // It goes directly from main memory to BT buffer.
    // =========================================================

    output reg                      mem_read,
    output reg [ADDR_WIDTH-1:0]     mem_addr,

    input  wire                      mem_rvalid,


    // =========================================================
    // B -> BT buffer control
    // =========================================================

    output reg                      buffer_load,
    output reg [1:0]                row_select,

    input  wire                      buffer_full,

    output reg                      buffer_clear,


    // =========================================================
    // Buffer MUX control
    // =========================================================

    output reg [3:0]                buffer_select,


    // =========================================================
    // BT BRAM control
    // =========================================================

    output reg                      BT_we,
    output reg [ADDR_WIDTH-1:0]     BT_wr_addr,


    // =========================================================
    // Status
    // =========================================================

    output reg                      busy,
    output reg                      done,
    output wire [3:0] state,
    output wire [15:0]              debug_B_row,
    output wire [15:0]              debug_B_col_group,
    output wire [ADDR_WIDTH-1:0]    debug_current_B_addr

);


    // =====================================================
    // FSM STATE DEFINITIONS
    // =====================================================

    localparam IDLE           = 4'd0;
    localparam ADDRESS_UPDATE = 4'd1;
    localparam READ_REQUEST   = 4'd2;
    localparam WAIT_MEMORY    = 4'd3;
    localparam STORE_BUFFER   = 4'd4;
    localparam CHECK_BUFFER   = 4'd5;
    localparam CALCULATE_BT   = 4'd6;
    localparam WRITE_BT       = 4'd7;
    localparam NEXT_GROUP     = 4'd8;
    localparam DONE_STATE     = 4'd9;


    // =====================================================
    // STATE REGISTERS
    // =====================================================

    reg [3:0] current_state;
    reg [3:0] next_state;
    
    // =====================================================
    // B_ADDR REGISTER
    // =====================================================
    reg [9:0] current_B_addr;
      
    // =====================================================
    // B ROW & COL REGISTERS
    // =====================================================

    reg [15:0] B_row;
    reg [15:0] B_row_next;
    reg [15:0] B_col_group;
    reg [15:0] B_col_group_next;
    
    // =====================================================
    // B_T ROW & COL REGISTERS
    // =====================================================
    reg        row_update;
    reg [15:0] BT_col_group;
    reg [15:0] BT_col_group_next;
    // =====================================================
    // Last Column & row check
    // =====================================================
    wire last_column_group;
    wire last_row;
    // =====================================================
    // Buffer Select Counter
    // =====================================================
    reg [1:0] buffer_select_count;
    reg [1:0] buffer_select_count_next;

    assign last_column_group = (B_col_group == (B_cols / 4) - 1);
    assign last_row = (B_row == B_rows - 1);
    assign state = current_state;
    assign debug_B_row = B_row;
    assign debug_B_col_group = B_col_group;
    assign debug_current_B_addr = current_B_addr;

    // =====================================================
    // SYNCHRONOUS STATE REGISTER
    // =====================================================

    always @(posedge clk) begin

        if (!reset) begin
            current_state <= IDLE;
        end
        else begin
            current_state <= next_state;
        end

    end
    
    // =====================================================
    // SYNCHRONOUS B_ROW / B_COL_GROUP REGISTERS
    // =====================================================

    always @(posedge clk) begin

        if (!reset) begin

            B_row       <= 16'd0;
            B_col_group <= 16'd0;
            BT_col_group<= 16'd0;
            buffer_select_count <= 2'd0;

        end
        else begin

            B_row       <= B_row_next;
            B_col_group <= B_col_group_next;
            BT_col_group<= BT_col_group_next;
            buffer_select_count <= buffer_select_count_next;

        end

    end

    // =====================================================
    // COMBINATIONAL NEXT STATE LOGIC
    // =====================================================

    always @(*) begin

    // Default: remain in current state
    next_state = current_state;

    case (current_state)

        // =============================================
        // IDLE
        // =============================================

        IDLE: begin

            if (start)
                next_state = ADDRESS_UPDATE;

        end


        // =============================================
        // ADDRESS UPDATE
        //
        // B_row / B_col_group are updated synchronously
        // while entering/leaving this state.
        // =============================================

        ADDRESS_UPDATE: begin

            next_state = READ_REQUEST;

        end


        // =============================================
        // READ REQUEST
        //
        // Memory read request is issued in this state.
        // =============================================

        READ_REQUEST: begin

            next_state = WAIT_MEMORY;

        end


        // =============================================
        // WAIT MEMORY
        //
        // Wait until synchronous memory returns data.
        // =============================================

        WAIT_MEMORY: begin

            if (mem_rvalid)
                next_state = STORE_BUFFER;

        end


        // =============================================
        // STORE BUFFER
        //
        // Store the returned memory word.
        // =============================================

        STORE_BUFFER: begin

            next_state = CHECK_BUFFER;

        end


        // =============================================
        // CHECK BUFFER
        // =============================================

        CHECK_BUFFER: begin

            if (buffer_full)
                next_state = CALCULATE_BT;
            else
                next_state = ADDRESS_UPDATE;

        end


        // =============================================
        // CALCULATE BT
        // =============================================

        CALCULATE_BT: begin

            next_state = WRITE_BT;

        end


        // =============================================
        // WRITE BT
        // =============================================

        WRITE_BT: begin

            if (buffer_select_count == 2'd3)
                next_state = NEXT_GROUP;
            else
                next_state = CALCULATE_BT;

        end

        // =============================================
        // NEXT GROUP
        // =============================================

        NEXT_GROUP: begin

            if (last_column_group && last_row)
                next_state = DONE_STATE;
            else
                next_state = ADDRESS_UPDATE;

        end


        // =============================================
        // DONE
        // =============================================

        DONE_STATE: begin

            next_state = DONE_STATE;

        end


        // =============================================
        // DEFAULT
        // =============================================

        default: begin

            next_state = IDLE;

        end

    endcase

    end
    
    // =====================================================
    // COMBINATIONAL B_ROW NEXT LOGIC
    // =====================================================

    always @(*) begin

    // Default: hold current values
        B_row_next       = B_row;

        if (current_state == CHECK_BUFFER) begin

            // ---------------------------------------------
            // Case 1: Not the last row
            // ---------------------------------------------

            if (!last_row) begin

                B_row_next = B_row + 16'd1;

            end

            // ---------------------------------------------
            // Case 2: Last row, but more column groups exist
            // ---------------------------------------------

            else if (!last_column_group && last_row) begin

                B_row_next       = 16'd0;
                row_update       = 1'd1;

            end

            // ---------------------------------------------
            // Case 3: Last row AND last column group
            // ---------------------------------------------

            else begin

                B_row_next       = B_row;

            end

        end

    end
    
    // =====================================================
    // COMBINATIONAL B_COL NEXT LOGIC
    // =====================================================
    always @(*) begin

        B_col_group_next = B_col_group;

        if (current_state == NEXT_GROUP) begin

            if (!last_column_group && row_update)
                B_col_group_next = B_col_group + 16'd1;
                row_update = 0;

        end

    end
    
    // =====================================================
    // COMBINATIONAL BT_COL_GROUP NEXT LOGIC
    // =====================================================
    always @(*) begin

        BT_col_group_next = BT_col_group;

        if (current_state == NEXT_GROUP) begin

            BT_col_group_next = B_row / 16'd4;

        end

    end
    
    // =====================================================
    // COMBINATIONAL B_ADDR LOGIC
    // =====================================================
    
    always @(*) begin

            current_B_addr = B_base + ((B_row * (B_cols / 4)) + B_col_group) * 4;
            mem_addr = current_B_addr;

    end
    // =====================================================
    // COMBINATIONAL MEMORY READ CONTROL
    // =====================================================

    always @(*) begin

        // Default
        mem_read = 1'b0;

        case (current_state)

            READ_REQUEST: begin
                mem_read = 1'b1;
            end

            WAIT_MEMORY: begin
                mem_read = 1'b1;
            end

            default: begin
                mem_read = 1'b0;
            end

        endcase

    end
    
    // =====================================================
    // COMBINATIONAL ROW SELECT
    // =====================================================

    always @(*) begin

        row_select = B_row % 16'd4;

    end
    
    // =====================================================
    // COMBINATIONAL BUFFER LOAD
    // =====================================================

    always @(*) begin

        buffer_load = 1'b0;

        if (current_state == STORE_BUFFER)
            buffer_load = 1'b1;

    end
    
    // =====================================================
    // COMBINATIONAL BUFFER SELECT LOGIC
    // =====================================================
    always @(*) begin

        case (buffer_select_count)

            2'd0: buffer_select = 4'b0001;
            2'd1: buffer_select = 4'b0010;
            2'd2: buffer_select = 4'b0100;
            2'd3: buffer_select = 4'b1000;

            default: buffer_select = 4'b0000;

        endcase

    end
    
    // =====================================================
    // COMBINATIONAL BUFFER SELECT COUNT LOGIC
    // =====================================================
    always @(*) begin

        buffer_select_count_next = buffer_select_count;

        if (current_state == WRITE_BT) begin

            if (buffer_select_count != 2'd3)
                buffer_select_count_next = buffer_select_count + 2'd1;
            else
                buffer_select_count_next = 2'd0;

        end

    end
    
    // =============================================
    // COMBINATIONAL BUFFER CLEAR
    // =============================================

    always @(*) begin

        buffer_clear = 1'b0;

        if (current_state == NEXT_GROUP)
            buffer_clear = 1'b1;

    end
    // =====================================================
    // COMBINATIONAL B_T ADDRESS CALCULATION
    // =====================================================

    always @(*) begin

        BT_wr_addr = BT_base + (((B_col_group * 16'd4) + buffer_select_count) * (B_rows / 16'd4) + BT_col_group) * 16'd4;

    end
    // =====================================================
    // COMBINATIONAL BT WRITE ENABLE
    // =====================================================

    always @(*) begin

        BT_we = 1'b0;

        case (current_state)

            CALCULATE_BT: begin
                BT_we = 1'b1;
            end

            WRITE_BT: begin
                BT_we = 1'b1;
            end

            default: begin
                BT_we = 1'b0;
            end

        endcase

    end
    
    
endmodule