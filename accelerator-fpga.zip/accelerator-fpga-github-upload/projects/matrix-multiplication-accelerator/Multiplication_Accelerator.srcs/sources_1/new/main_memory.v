
`timescale 1ns / 1ps

module main_memory #(
    parameter DATA_WIDTH = 32,
    parameter ADDR_WIDTH = 12
)(
    input  wire                     clk,

    input  wire                     mem_read,
    input  wire                     mem_write,

    input  wire [ADDR_WIDTH-1:0]    address,
    input  wire [DATA_WIDTH-1:0]    write_data,

    output reg  [DATA_WIDTH-1:0]    read_data,

    output reg                      mem_rvalid,
    output reg                      mem_wvalid
);

    // =========================================================
    // MEMORY
    // =========================================================

    localparam DEPTH = 1024;

    reg [DATA_WIDTH-1:0] memory [0:DEPTH-1];

    wire [ADDR_WIDTH-1:0] word_address;

    assign word_address = address >> 2;


    // =========================================================
    // READ / WRITE
    // =========================================================

    always @(posedge clk) begin

        mem_rvalid <= 1'b0;
        mem_wvalid <= 1'b0;

        // READ
        if (mem_read) begin
            read_data  <= memory[word_address];
            mem_rvalid <= 1'b1;
        end

        // WRITE
        if (mem_write) begin
            memory[word_address] <= write_data;
            mem_wvalid            <= 1'b1;
        end

    end


    // =========================================================
    // MANUAL MEMORY PRELOAD
    //
    // B = 8 x 8
    //
    //       C0 C1 C2 C3 C4 C5 C6 C7
    // R0     1  2  3  4  5  6  7  8
    // R1     9 10 11 12 13 14 15 16
    // R2    17 18 19 20 21 22 23 24
    // R3    25 26 27 28 29 30 31 32
    // R4    33 34 35 36 37 38 39 40
    // R5    41 42 43 44 45 46 47 48
    // R6    49 50 51 52 53 54 55 56
    // R7    57 58 59 60 61 62 63 64
    //
    // Four INT8 values per 32-bit word
    //
    // Word 0  = 04 03 02 01
    // Word 1  = 08 07 06 05
    // ...
    // Word 15 = 40 3F 3E 3D
    // =========================================================

    initial begin

        // -----------------------------------------------------
        // Initialize B = 8 x 8
        // -----------------------------------------------------

        memory[0]  = 32'h04030201;
        memory[1]  = 32'h08070605;

        memory[2]  = 32'h0C0B0A09;
        memory[3]  = 32'h100F0E0D;

        memory[4]  = 32'h14131211;
        memory[5]  = 32'h18171615;

        memory[6]  = 32'h1C1B1A19;
        memory[7]  = 32'h201F1E1D;

        memory[8]  = 32'h24232221;
        memory[9]  = 32'h28272625;

        memory[10] = 32'h2C2B2A29;
        memory[11] = 32'h302F2E2D;

        memory[12] = 32'h34333231;
        memory[13] = 32'h38373635;

        memory[14] = 32'h3C3B3A39;
        memory[15] = 32'h403F3E3D;


        // -----------------------------------------------------
        // Initialize remaining locations
        // -----------------------------------------------------

        memory[16] = 32'h00000000;
        memory[17] = 32'h00000000;
        memory[18] = 32'h00000000;
        memory[19] = 32'h00000000;


        // -----------------------------------------------------
        // Display preload
        // -----------------------------------------------------

        #1;

        $display("");
        $display("======================================");
        $display("MAIN MEMORY B PRELOAD : 8 x 8");
        $display("======================================");

        $display("memory[0]  = %08h", memory[0]);
        $display("memory[1]  = %08h", memory[1]);
        $display("memory[2]  = %08h", memory[2]);
        $display("memory[3]  = %08h", memory[3]);
        $display("memory[4]  = %08h", memory[4]);
        $display("memory[5]  = %08h", memory[5]);
        $display("memory[6]  = %08h", memory[6]);
        $display("memory[7]  = %08h", memory[7]);
        $display("memory[8]  = %08h", memory[8]);
        $display("memory[9]  = %08h", memory[9]);
        $display("memory[10] = %08h", memory[10]);
        $display("memory[11] = %08h", memory[11]);
        $display("memory[12] = %08h", memory[12]);
        $display("memory[13] = %08h", memory[13]);
        $display("memory[14] = %08h", memory[14]);
        $display("memory[15] = %08h", memory[15]);

        $display("======================================");
        $display("");

    end

endmodule