`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 27.08.2026 21:37:02
// Design Name: 
// Module Name: buffer_select_mux
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module buffer_select_mux #(
    parameter DATA_WIDTH = 32
)(
    input  wire [DATA_WIDTH-1:0] buf0,
    input  wire [DATA_WIDTH-1:0] buf1,
    input  wire [DATA_WIDTH-1:0] buf2,
    input  wire [DATA_WIDTH-1:0] buf3,

    // One-hot select
    input  wire [3:0] buffer_select,

    output reg  [DATA_WIDTH-1:0] data_out
);

    always @(*) begin

        // Default output
        data_out = {DATA_WIDTH{1'b0}};

        case (buffer_select)

            4'b0001: data_out = buf0;
            4'b0010: data_out = buf1;
            4'b0100: data_out = buf2;
            4'b1000: data_out = buf3;

            default: data_out = {DATA_WIDTH{1'b0}};

        endcase

    end

endmodule
