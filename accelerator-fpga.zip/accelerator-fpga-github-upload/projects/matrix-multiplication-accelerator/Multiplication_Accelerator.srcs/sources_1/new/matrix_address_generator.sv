module matrix_address_generator #(
    parameter integer A_ROWS     = 3,
    parameter integer COMMON     = 4,
    parameter integer B_COLS     = 5,
    parameter integer DATA_WIDTH = 32,
    parameter integer ADDR_WIDTH = 32
)(
    input  logic [ADDR_WIDTH-1:0] A_base,
    input  logic [ADDR_WIDTH-1:0] B_base,

    // Current C[i][j]
    input  logic [ADDR_WIDTH-1:0] i,
    input  logic [ADDR_WIDTH-1:0] j,

    // Addresses for n parallel multiplication units
    output logic [ADDR_WIDTH-1:0] A_addr [0:COMMON-1],
    output logic [ADDR_WIDTH-1:0] B_addr [0:COMMON-1]
);

    localparam integer ELEMENT_BYTES = DATA_WIDTH / 8;

    // Address stride for A
    localparam integer A_STRIDE = ELEMENT_BYTES;

    // Address stride for B
    localparam integer B_STRIDE = B_COLS * ELEMENT_BYTES;

    logic [ADDR_WIDTH-1:0] A_start;
    logic [ADDR_WIDTH-1:0] B_start;

    integer k;

    always_comb begin

        // Starting address for A[i][0]
        A_start = A_base
                + (i * COMMON * ELEMENT_BYTES);

        // Starting address for B[0][j]
        B_start = B_base
                + (j * ELEMENT_BYTES);

        // Generate addresses for all parallel MAC units
        for (k = 0; k < COMMON; k = k + 1) begin

            // A[i][k]
            A_addr[k] = A_start
                      + (k * A_STRIDE);

            // B[k][j]
            B_addr[k] = B_start
                      + (k * B_STRIDE);

        end

    end

endmodule