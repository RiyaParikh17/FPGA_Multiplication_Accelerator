`timescale 1ns / 1ps

module generic_bram #(
    parameter DATA_WIDTH = 32,
    parameter ADDR_WIDTH = 10
)(
    input  wire                  clk,

    // Write interface
    input  wire                  we,
    input  wire [ADDR_WIDTH-1:0] wr_addr,
    input  wire [DATA_WIDTH-1:0] wr_data,

    // Read interface
    input  wire [ADDR_WIDTH-1:0] rd_addr,
    output reg  [DATA_WIDTH-1:0] rd_data,

    // Debug memory
    output wire [(DATA_WIDTH*(1<<ADDR_WIDTH))-1:0] debug_memory
);

    // =========================================================
    // MEMORY
    // =========================================================

    localparam DEPTH = (1 << ADDR_WIDTH);

    reg [DATA_WIDTH-1:0] mem [0:DEPTH-1];


    // =========================================================
    // BYTE ADDRESS -> WORD ADDRESS
    //
    // External interface uses BYTE addresses.
    //
    // 64 -> 16
    // 68 -> 17
    // 72 -> 18
    // 76 -> 19
    //
    // Each 32-bit word occupies 4 bytes.
    // =========================================================

    wire [ADDR_WIDTH-1:0] wr_word_address;
    wire [ADDR_WIDTH-1:0] rd_word_address;

    assign wr_word_address = wr_addr >> 2;
    assign rd_word_address = rd_addr >> 2;


    // =========================================================
    // DEBUG MEMORY
    // =========================================================

    genvar i;

    generate
        for (i = 0; i < DEPTH; i = i + 1) begin : DEBUG_MEMORY_MAP

            assign debug_memory[
                (i*DATA_WIDTH) +: DATA_WIDTH
            ] = mem[i];

        end
    endgenerate


    // =========================================================
    // SYNCHRONOUS WRITE AND READ
    // =========================================================

    always @(posedge clk) begin

        // -----------------------------------------------------
        // WRITE
        // -----------------------------------------------------

        if (we) begin
            mem[wr_word_address] <= wr_data;
        end


        // -----------------------------------------------------
        // READ
        // -----------------------------------------------------

        rd_data <= mem[rd_word_address];

    end

endmodule